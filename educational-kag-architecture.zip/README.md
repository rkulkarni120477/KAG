# US Educational KAG — architecture package

Design baseline: **10 November 2026**. Audience: enterprise architects, education leaders, and implementation teams.

[Download the complete package](educational-kag-architecture.zip).

- [Detailed architecture and all ten deliverables](docs/architecture.md)
- [Logical architecture — 4K PNG](diagrams/logical-architecture.png) · [editable SVG](diagrams/logical-architecture.svg)
- [AWS deployment — 4K PNG](diagrams/aws-deployment.png) · [editable SVG](diagrams/aws-deployment.svg)
- [Query sequence — 4K PNG](diagrams/query-sequence.png) · [editable SVG](diagrams/query-sequence.svg)
- [Knowledge graph model — 4K PNG](diagrams/knowledge-graph.png) · [editable SVG](diagrams/knowledge-graph.svg)
- [Docker Compose blueprint](deployment/compose.yaml) · [setup and limitations](deployment/README.md)
- [FastAPI implementation structure](implementation/STRUCTURE.md) · [typed contracts](implementation/contracts.py) · [Bedrock adapter example](implementation/bedrock_adapter.py)
- [Diagram source and regeneration](tools/render_diagrams.py)

This is an architecture and implementation blueprint, not a completed platform or an AWS deployment. The Compose application profile requires application images built from the proposed implementation. No infrastructure has been provisioned, and no student data has been loaded.
